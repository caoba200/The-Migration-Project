
// Post/Repost validation
var post = document.getElementById("post_content");

post.addEventListener("blur", CheckPost, false);
post.addEventListener("keyup", CheckCounter, false);